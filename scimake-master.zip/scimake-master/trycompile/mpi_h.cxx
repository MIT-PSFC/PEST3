/**
 * $Rev$ $Date$
 *
 * Copyright &copy; 2012-2017, Tech-X Corporation, Boulder, CO.
 * See LICENSE file (EclipseLicense.txt) for conditions of use.
 */

#include <mpi.h>

int main(int argc, char** argv) {
  return 0;
}

